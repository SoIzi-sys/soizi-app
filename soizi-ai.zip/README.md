# So Izi Plataforma

Plataforma inteligente para engenheiros de alimentos com IA, exportação PDF, P&D, Regulatórios e muito mais.